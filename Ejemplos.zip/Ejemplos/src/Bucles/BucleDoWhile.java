package Bucles;

import java.util.Scanner;

public class BucleDoWhile {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int numero; // suma = 0; SUMA lo quitamos para el ejemplo del INTERRUPTOR / esto se pone debajo de las variables "suma = 0;"
		boolean par = false;
		
		
		do {
			System.out.println("Dime un número (0 para terminar):");
			numero = teclado.nextInt();
			if (numero % 2 == 0 && numero != 0) { //Aquí le decimos que vea si es par y si es igual a 0 no lo cuente
					par = true;
			}
			
			} while (numero != 0); //hasta que no pongamos un 0 no parará de añadir números a la suma
		
		if (par == true) { 
			System.out.println("Algún número era par");
			
		} else if (par == false)
			System.out.println("Ningun número era par");
	
	}

}
