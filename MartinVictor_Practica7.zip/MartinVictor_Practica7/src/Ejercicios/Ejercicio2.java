//Autor: Víctor Martín Garrido
// Fecha: 14/10/2026
// Objetivo: Modificar el programa del ejercicio 1 para que a demás de darnos el resultado de si el candidato pueda o no ser contratado, nos diga el salario que va a tener.

package Ejercicios;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		String apellidos;
		int edad;
		int salario_des;
		int exp_ant;
		int proy_ant;
		int salario_dado;
		
		System.out.println("Diganos los siguientes datos: ");
		
		System.out.print("Nombre: ");
		nombre=teclado.nextLine();
		
		System.out.print("Apellidos: ");
		apellidos=teclado.nextLine();
		
		System.out.print("Edad: ");
		edad=teclado.nextInt();
		
		System.out.print("Salario deseado: ");
		salario_des=teclado.nextInt();
		
		
		 if (salario_des < 30000 && edad <= 45) {
		      System.out.println("-- Ahora responda los siguientes datos --");
		      
		      teclado.nextLine();
		      
		      System.out.print("Años de experiencia: ");
		      exp_ant = teclado.nextInt();
		      
		      System.out.print("Proyectos trabajados anteriores: ");
		      proy_ant = teclado.nextInt();
		      
		      
		  if (exp_ant >= 2 && proy_ant >= 3) {
		          System.out.print("Enhorabuena. Ha sido contratado. ");
		      } else {
		          System.out.print("Lo sentimos pero no cumple el perfil.");
		      }
		 
		  
		  if (exp_ant > 5 && proy_ant > 5) {
			  System.out.print("Usted recibirá de salario 30,000€ anuales.");
			  
		  }else if (exp_ant < 5 && proy_ant < 5){
			  System.out.print("Usted recibirá de salario 25,000€ anuales.");
		  }
		
		 }
		
		

	}

}
