//Autor: Víctor Martín Garrido
// Fecha: 14/10/2026
// Objetivo: Crear un programa en el que utilizando un switch, podamos saber la calificación correspondiente en cada caso, las notas admitidas son del 0 al 10.

package Ejercicios;

import java.util.Scanner;

public class Ejercicio3 {
	
    public static void main(String[] args) {
    	
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Introduce una nota en valor entero (0 al 10): ");
        int nota = teclado.nextInt(); //Asi inicializamos la variable a la vez que la creamos
        
        switch (nota) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                System.out.println("Calificación: Suspenso");
                break;
            case 5:
                System.out.println("Calificación: Suficiente");
                break;
            case 6:
                System.out.println("Calificación: Bien");
                break;
            case 7:
            case 8:
                System.out.println("Calificación: Notable");
                break;
            case 9:
            case 10:
                System.out.println("Calificación: Sobresaliente");
                break;
            default:
                System.out.println("La nota introducida ha sido incorrecta.");
                break;
        }
    }
}