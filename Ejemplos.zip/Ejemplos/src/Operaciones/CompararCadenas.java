package Operaciones;

import java.util.Scanner;

public class CompararCadenas {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nombre;

        do {
            System.out.println("Dime un nombre (escribe final para terminar):");
            nombre = teclado.nextLine();

            if (nombre.equals("Pepe")) {
                System.out.println("¡Enhorabuena! Lo has adivinado.");
            }

        } while (nombre.equalsIgnoreCase("final"));

        System.out.println("Programa terminado.");
        teclado.close();
    }
}