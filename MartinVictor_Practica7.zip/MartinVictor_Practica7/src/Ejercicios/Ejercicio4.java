//Autor: Víctor Martín Garrido
// Fecha: 14/10/2026
// Objetivo: Crear un programa que calcule la media original como la redondeada tanto para arriba como para abajo para saber si el alumno puede acceder a los estudios superiores

package Ejercicios;

import java.util.Scanner;

public class Ejercicio4 {
	
    public static void main(String[] args) {
    	
    	Scanner teclado = new Scanner(System.in);
        
        // Solicitar al usuario la nota media obtenida en 4 asignaturas de tipo double
        System.out.print("Introduce la nota de la primera asignatura: ");
        double nota1 = teclado.nextDouble();
        
        System.out.print("Introduce la nota de la segunda asignatura: ");
        double nota2 = teclado.nextDouble();
        
        System.out.print("Introduce la nota de la tercera asignatura: ");
        double nota3 = teclado.nextDouble();
        
        System.out.print("Introduce la nota de la cuarta asignatura: ");
        double nota4 = teclado.nextDouble();
        
        // Calcular la nota media y mostrarla al usuario
        double notaMedia = (nota1 + nota2 + nota3 + nota4) / 4.0;
        System.out.println("La nota media es: " + notaMedia);
        
        // Mostrar la nota media redondeada hacia arriba
        System.out.println("Nota media redondeada hacia arriba: " + Math.ceil(notaMedia));
        
        // Mostrar la nota media redondeada hacia abajo
        System.out.println("Nota media redondeada hacia abajo: " + Math.floor(notaMedia));
        
        // Comprobar si supera o iguala el 8
        if (notaMedia >= 8) {
            System.out.println("Puede acceder a estudios superiores.");
        } else {
            System.out.println("La nota media obtenida no es suficiente para acceder a los estudios que deseaba.");
        }
        
        
    }
}